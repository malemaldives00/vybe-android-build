package com.vybe.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.GoogleAuthProvider;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.KeyEvent;
import android.util.Patterns;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends Activity {
    private WebView webView;
    private FirebaseAuth auth;
    private GoogleSignInClient googleClient;
    private static final int RC_GOOGLE = 7401;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        String webClientId = "134636520255-9tghcg6isdtumj0mqgtqatae6f34if5j.apps.googleusercontent.com";
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(webClientId).requestEmail().build();
        googleClient = GoogleSignIn.getClient(this, gso);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new VybeBridge(), "VybeNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                FirebaseUser user = auth.getCurrentUser();
                String name = user != null && user.getDisplayName() != null ? user.getDisplayName() : "";
                String safeName = name.replace("\\", "\\\\").replace("'", "\\'");
                view.evaluateJavascript("window.onNativeAuthState && window.onNativeAuthState(" + (user != null) + ", '" + safeName + "')", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void sendResult(String kind, boolean ok, String message) {
        if (webView == null) return;
        String safe = message == null ? "" : message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        runOnUiThread(() -> webView.evaluateJavascript("window.onNativeAuthResult && window.onNativeAuthResult('" + kind + "'," + ok + ",'" + safe + "')", null));
    }

    private String readableError(Exception e) {
        String m = e == null || e.getMessage() == null ? "" : e.getMessage();
        if (m.contains("email address is badly formatted")) return "Email address is not valid.";
        if (m.contains("password is invalid") || m.contains("INVALID_LOGIN_CREDENTIALS") || m.contains("wrong-password")) return "Email or password is incorrect.";
        if (m.contains("no user record") || m.contains("user-not-found")) return "No account found for this email.";
        if (m.contains("email address is already in use") || m.contains("email-already-in-use")) return "This email already has an account. Please log in.";
        if (m.contains("network")) return "Network error. Check your internet connection.";
        if (m.contains("WEAK_PASSWORD") || m.contains("at least 6 characters")) return "Choose a password with at least 6 characters.";
        if (m.contains("OPERATION_NOT_ALLOWED") || m.contains("operation-not-allowed") || m.contains("CONFIGURATION_NOT_FOUND")) return "Firebase Email/Password sign-in is not enabled. Open Firebase Console > Authentication > Sign-in method and enable Email/Password.";
        if (m.contains("TOO_MANY_ATTEMPTS_TRY_LATER")) return "Too many attempts. Please wait and try again later.";
        if (m.contains("INVALID_EMAIL")) return "Enter a valid email address, not a phone number.";
        if (m.contains("API_KEY_INVALID") || m.contains("INVALID_API_KEY")) return "Firebase configuration is invalid. Check app/google-services.json.";
        return "Could not complete this request. Check internet, Firebase Email/Password settings, and your details. (" + m + ")";
    }

    private class VybeBridge {
        @JavascriptInterface public void signup(String name, String email, String password) {
            if (name == null || name.trim().isEmpty() || email == null || !Patterns.EMAIL_ADDRESS.matcher(email).matches() || password == null || password.length() < 6) {
                sendResult("signup", false, "Enter your name, a valid email, and a password of at least 6 characters."); return;
            }
            auth.createUserWithEmailAndPassword(email.trim(), password).addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult() != null && task.getResult().getUser() != null) {
                    task.getResult().getUser().updateProfile(new com.google.firebase.auth.UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build())
                        .addOnCompleteListener(profileTask -> sendResult("signup", true, name.trim()));
                } else sendResult("signup", false, readableError(task.getException()));
            });
        }
        @JavascriptInterface public void login(String email, String password) {
            if (email == null || !Patterns.EMAIL_ADDRESS.matcher(email).matches() || password == null || password.isEmpty()) { sendResult("login", false, "Enter a valid email and password."); return; }
            auth.signInWithEmailAndPassword(email.trim(), password).addOnCompleteListener(task -> {
                if (task.isSuccessful()) sendResult("login", true, ""); else sendResult("login", false, readableError(task.getException()));
            });
        }
        @JavascriptInterface public void googleSignIn() { runOnUiThread(() -> startActivityForResult(googleClient.getSignInIntent(), RC_GOOGLE)); }
        // Phone + password is implemented as a Firebase email/password alias. It does NOT verify ownership of the phone number.
        private String phoneAlias(String phone) { String digits = phone.replaceAll("[^0-9]", ""); return "phone_" + digits + "@phone.vybe.invalid"; }
        @JavascriptInterface public void phoneSignup(String name, String phone, String password) {
            if (name == null || name.trim().isEmpty() || phone == null || !phone.matches("\\+?[0-9]{7,15}") || password == null || password.length() < 6) { sendResult("phone", false, "Enter your name, valid phone number, and password of at least 6 characters."); return; }
            auth.createUserWithEmailAndPassword(phoneAlias(phone), password).addOnCompleteListener(task -> { if(task.isSuccessful() && task.getResult()!=null && task.getResult().getUser()!=null){ task.getResult().getUser().updateProfile(new com.google.firebase.auth.UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build()).addOnCompleteListener(t -> sendResult("phone", true, name.trim())); } else sendResult("phone", false, readableError(task.getException())); });
        }
        @JavascriptInterface public void phoneLogin(String phone, String password) {
            if (phone == null || !phone.matches("\\+?[0-9]{7,15}") || password == null || password.isEmpty()) { sendResult("phone", false, "Enter a valid phone number and password."); return; }
            auth.signInWithEmailAndPassword(phoneAlias(phone), password).addOnCompleteListener(task -> { if(task.isSuccessful()) sendResult("phone", true, ""); else sendResult("phone", false, "Phone login failed. If this account was created with email, use Email + Password. " + readableError(task.getException())); });
        }
        @JavascriptInterface public void resetPassword(String email) {
            if (email == null || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) { sendResult("reset", false, "Enter a valid email address."); return; }
            auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener(task -> {
                if (task.isSuccessful()) sendResult("reset", true, ""); else sendResult("reset", false, readableError(task.getException()));
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_GOOGLE) {
            try {
                GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
                auth.signInWithCredential(credential).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) sendResult("google", true, account.getDisplayName() == null ? "" : account.getDisplayName());
                    else sendResult("google", false, readableError(task.getException()));
                });
            } catch (ApiException e) { sendResult("google", false, "Google sign-in cancelled or failed (" + e.getStatusCode() + "). Check OAuth client and SHA-1/SHA-256 in Firebase."); }
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
