VYBE authentication options update

Added UI/actions for Email + Password, Phone + Password alias flow, and Google Sign-In.

Important limitations / required setup:
- Google Sign-In requires the Android app signing SHA-1 and SHA-256 fingerprints added in Firebase Console > Project settings > Your apps, Google provider enabled under Authentication, and a fresh APK build. Confirm the web OAuth client ID in MainActivity.java matches your Firebase project.
- Phone + Password here uses a synthetic Firebase email alias (phone_<digits>@phone.vybe.invalid). It does NOT verify that the user owns the phone number, and is not equivalent to Firebase Phone OTP. Do not use for sensitive accounts. To verify phone ownership, replace this with Firebase Phone Auth + OTP or a secure backend.
- Email + Password requires Email/Password provider enabled in Firebase Authentication.
- These are source changes, not a built/verified APK. Replace files in your repo, run GitHub Actions, install the new artifact and test.
