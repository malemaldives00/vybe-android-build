VYBE Firebase Login/Signup source package

Included fixes:
- app/google-services.json is included at the correct path.
- Google Services Gradle plugin is configured.
- Android INTERNET permission is enabled.
- Login and email/password Sign Up call Firebase Authentication REST API.
- Auth token, UID, and email are stored locally after successful login.
- Existing UI and other HTML app screens are preserved.

IMPORTANT:
1. In Firebase Console for project vybe-1a2c7, open Authentication > Sign-in method and enable Email/Password.
2. This package does NOT yet implement Google sign-in, Firestore user profiles, chat/voice backend, or real payments.
3. A successful APK build has not been verified here. If GitHub Actions shows another error, share the exact log.
