VYBE APK Build — পরের ধাপ

১) এই ZIP extract করে সব ফাইল GitHub repository-র main branch-এ upload করো। ফোল্ডারের ভিতরের ফাইল upload করবে; ZIP-টাকে ZIP হিসেবেই repo-তে রেখে দিলে workflow চলবে না।
২) GitHub repository → Actions → “Build VYBE APK” → Run workflow চাপো।
৩) কাজ শেষ হলে green check-এ ঢুকে Artifacts থেকে VYBE-debug-APK download করো।
৪) Firebase Console → Authentication → Sign-in method → Email/Password enable করে Save করো।

এই ZIP-এ .github/workflows/android.yml যোগ করা হয়েছে। APK build এখানে চালিয়ে যাচাই করা হয়নি; GitHub Actions-এর ফলাফল না আসা পর্যন্ত build সফল বলা যাবে না।
