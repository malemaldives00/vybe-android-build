package com.vybe.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.KeyEvent;
import android.util.Patterns;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends Activity {
    private WebView webView;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new VybeBridge(), "VybeNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                FirebaseUser user = auth.getCurrentUser();
                String name = user != null && user.getDisplayName() != null ? user.getDisplayName() : "";
                String safeName = name.replace("\\", "\\\\").replace("'", "\\'");
                view.evaluateJavascript("window.onNativeAuthState && window.onNativeAuthState(" + (user != null) + ", '" + safeName + "')", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void sendResult(String kind, boolean ok, String message) {
        if (webView == null) return;
        String safe = message == null ? "" : message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        runOnUiThread(() -> webView.evaluateJavascript("window.onNativeAuthResult && window.onNativeAuthResult('" + kind + "'," + ok + ",'" + safe + "')", null));
    }

    private String readableError(Exception e) {
        String m = e == null || e.getMessage() == null ? "" : e.getMessage();
        if (m.contains("email address is badly formatted")) return "Email address is not valid.";
        if (m.contains("password is invalid") || m.contains("INVALID_LOGIN_CREDENTIALS") || m.contains("wrong-password")) return "Email or password is incorrect.";
        if (m.contains("no user record") || m.contains("user-not-found")) return "No account found for this email.";
        if (m.contains("email address is already in use") || m.contains("email-already-in-use")) return "This email already has an account. Please log in.";
        if (m.contains("network")) return "Network error. Check your internet connection.";
        if (m.contains("WEAK_PASSWORD") || m.contains("at least 6 characters")) return "Choose a password with at least 6 characters.";
        return "Could not complete this request. Check your details and try again.";
    }

    private class VybeBridge {
        @JavascriptInterface public void signup(String name, String email, String password) {
            if (name == null || name.trim().isEmpty() || email == null || !Patterns.EMAIL_ADDRESS.matcher(email).matches() || password == null || password.length() < 6) {
                sendResult("signup", false, "Enter your name, a valid email, and a password of at least 6 characters."); return;
            }
            auth.createUserWithEmailAndPassword(email.trim(), password).addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult() != null && task.getResult().getUser() != null) {
                    task.getResult().getUser().updateProfile(new com.google.firebase.auth.UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build())
                        .addOnCompleteListener(profileTask -> sendResult("signup", true, name.trim()));
                } else sendResult("signup", false, readableError(task.getException()));
            });
        }
        @JavascriptInterface public void login(String email, String password) {
            if (email == null || !Patterns.EMAIL_ADDRESS.matcher(email).matches() || password == null || password.isEmpty()) { sendResult("login", false, "Enter a valid email and password."); return; }
            auth.signInWithEmailAndPassword(email.trim(), password).addOnCompleteListener(task -> {
                if (task.isSuccessful()) sendResult("login", true, ""); else sendResult("login", false, readableError(task.getException()));
            });
        }
        @JavascriptInterface public void resetPassword(String email) {
            if (email == null || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) { sendResult("reset", false, "Enter a valid email address."); return; }
            auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener(task -> {
                if (task.isSuccessful()) sendResult("reset", true, ""); else sendResult("reset", false, readableError(task.getException()));
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
