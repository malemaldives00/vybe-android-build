VYBE Android WebView demo project

এই প্রজেক্টে VYBE_Demo_Checked.html ফাইলটি Android অ্যাপের ভিতরে চালানোর জন্য রাখা হয়েছে।
এটি এখনো শুধু HTML ডেমোকে Android অ্যাপে খোলে; বাস্তব লাইভ ভিডিও, সার্ভার-ভিত্তিক অ্যাকাউন্ট, অনলাইন ফলো/ফলোয়ার সিঙ্ক এবং আসল পেমেন্ট এতে নেই।

APK তৈরির ধাপ:
1. পুরো VYBE_Android_Project.zip GitHub-এ একটি নতুন repository-তে upload করো (ZIP extract করে ভিতরের ফাইলগুলো upload করতে হবে, ZIP-টিকে শুধু repository-তে রেখে দিলে হবে না)।
2. GitHub repository-র Actions tab খোলো।
3. “Build VYBE APK” workflow বেছে Run workflow চাপো।
4. Build সফল হলে নিচের Artifacts অংশে vybe-debug-apk ডাউনলোড করো।
5. APK Android ফোনে install করার আগে GitHub Actions build সফল হয়েছে কি না দেখো।

প্রয়োজন: GitHub account এবং Actions চালানোর অনুমতি। এটি Play Store release/signing-এর জন্য প্রস্তুত signed release APK নয়; debug APK তৈরি করে।
