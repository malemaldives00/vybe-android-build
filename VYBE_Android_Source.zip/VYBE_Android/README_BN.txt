VYBE Android App Source (starter build)

এটি VYBE-এর HTML prototype-কে Android WebView অ্যাপের মধ্যে চালানোর জন্য তৈরি Android Studio project source। এই পরিবেশে Android SDK/Gradle build tool নেই, তাই এখান থেকে APK compile করে যাচাই করা সম্ভব হয়নি।

APK বানানোর নিয়ম:
1. Android Studio-সহ কম্পিউটারে এই ফোল্ডারটি খুলুন।
2. Gradle sync সম্পন্ন করুন (Android SDK Platform 35 ইনস্টল থাকতে হবে)।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
4. তৈরি APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ থাকবে।

সীমাবদ্ধতা:
এটি এখনো prototype wrapper; live multi-user accounts, secure backend, voice/video rooms, real gifts/payments, notifications, moderation/admin tools এখনো বাস্তবভাবে যুক্ত হয়নি। এই সোর্স নিজে থেকে এসব ফিচার তৈরি করে না।

মালিকানা:
নিজের Android Studio/Google Play Console, signing key, server এবং database account ব্যবহার করুন। Signing key/password অন্যকে দেবেন না।
