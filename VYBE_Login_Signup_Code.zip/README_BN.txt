VYBE Android Project Source

এটি Android Studio source project; এটি তৈরি করা APK নয়।

এই সংস্করণে সর্বশেষ VYBE_Full_App_Demo_Back_Button.html ফাইলটি app/src/main/assets/index.html হিসেবে যুক্ত আছে। HTML demo-তে page navigation history ও popstate ব্যবহৃত হয়েছে। Android WebView-এর Back handler WebView history থাকলে আগের history entry-তে ফেরে।

APK বানানোর ধাপ:
1. ZIP extract করুন।
2. Android Studio-তে extracted project folder খুলুন।
3. Gradle sync সম্পন্ন হতে দিন (Android SDK 35 এবং compatible JDK প্রয়োজন হতে পারে)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।

পরীক্ষার ফল:
- ZIP archive integrity: OK
- Bundled HTML JavaScript syntax: node --check PASS
- Duplicate HTML IDs: none found
- Navigation history code (pushState/popstate): present

সীমাবদ্ধতা:
- এই পরিবেশে Android SDK/Gradle build চালানো যায়নি; তাই APK compilation নিশ্চিত করা হয়নি।
- প্রতিটি UI button বাস্তবে tap করে end-to-end test করা হয়নি।
- Login, database, server, real payments, real streaming/chat backend যুক্ত নয়; এগুলো demo UI।

AUTH UI UPDATE (2026-10-25)
- Existing VYBE home/demo and launcher icon assets have been retained.
- Login/Signup/Forgot Password UI added over the existing app.
- Real authentication is NOT ready until Firebase configuration is added.
- Email signup creates Firebase email/password account and sends email verification link (not numeric email OTP).
- Phone signup uses Firebase SMS OTP.
- Google sign-in button uses Firebase web popup; Android WebView may block popup. For production, implement native Google sign-in with Credential Manager and exchange credential with Firebase.
- Phone login by password is not enabled in this frontend; Firebase phone authentication normally uses SMS verification instead.
- Android SDK build and end-to-end Firebase tests have not been run in this environment.

FIREBASE SETUP
1. Open https://console.firebase.google.com and create/select a Firebase project.
2. Add a Web app; copy its config object.
3. Enable Authentication > Sign-in method: Email/Password, Phone, and Google.
4. In app/src/main/assets/index.html, find `const cfg=window.VYBE_FIREBASE_CONFIG||null;` and replace it by a config object declaration:
   const cfg={apiKey:'YOUR_API_KEY',authDomain:'YOUR_PROJECT.firebaseapp.com',projectId:'YOUR_PROJECT_ID',appId:'YOUR_APP_ID'};
   (Use the exact values from Firebase; do not share private service-account keys.)
5. Phone auth requires Firebase authorized domain/configuration and SMS quota; test with Firebase test phone numbers first.
6. Build the Android project using Android Studio. Google auth in a WebView may need native Android implementation and SHA-1/SHA-256 fingerprints.
