VYBE Android Project Source

এটি Android Studio source project; এটি তৈরি করা APK নয়।

এই সংস্করণে সর্বশেষ VYBE_Full_App_Demo_Back_Button.html ফাইলটি app/src/main/assets/index.html হিসেবে যুক্ত আছে। HTML demo-তে page navigation history ও popstate ব্যবহৃত হয়েছে। Android WebView-এর Back handler WebView history থাকলে আগের history entry-তে ফেরে।

APK বানানোর ধাপ:
1. ZIP extract করুন।
2. Android Studio-তে extracted project folder খুলুন।
3. Gradle sync সম্পন্ন হতে দিন (Android SDK 35 এবং compatible JDK প্রয়োজন হতে পারে)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।

পরীক্ষার ফল:
- ZIP archive integrity: OK
- Bundled HTML JavaScript syntax: node --check PASS
- Duplicate HTML IDs: none found
- Navigation history code (pushState/popstate): present

সীমাবদ্ধতা:
- এই পরিবেশে Android SDK/Gradle build চালানো যায়নি; তাই APK compilation নিশ্চিত করা হয়নি।
- প্রতিটি UI button বাস্তবে tap করে end-to-end test করা হয়নি।
- Login, database, server, real payments, real streaming/chat backend যুক্ত নয়; এগুলো demo UI।
